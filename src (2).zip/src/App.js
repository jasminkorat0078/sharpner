import Expenses from "./components/Expenses/Expenses";
import NewExpense from "./components/NewExpense/NewExpense";
function App() {
  const expenses = [
    {
      title: "car Insuarance",
      date: new Date(2022, 2, 28),
      amount: 2000,
      location: "ahmedabad",
    },
    {
      title: "home loan",
      date: new Date(2022, 2, 29),
      amount: 15000,
      location: "ahmedabad",
    },
    {
      title: "clothes",
      date: new Date(2022, 2, 30),
      amount: 5000,
      location: "mumbai",
    },
    {
      title: "Misc.",
      date: new Date(2022, 2, 31),
      amount: 8000,
      location: "srinagar",
    },
    {
      title: "shoes.",
      date: new Date(2022, 2, 30),
      amount: 1500,
      location: "rishikesh",
    },
  ];

  return (
    <div>
      <NewExpense></NewExpense>
      <Expenses items={expenses} />
    </div>
  );
}

export default App;
