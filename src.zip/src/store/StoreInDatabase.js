import { useSelector } from "react-redux";
import { useEffect } from "react";

const StoreInDatabase = props =>{
    const cart = useSelector(state =>state.cart);

    useEffect(()=>{
      fetch('https://foodorder-4d851-default-rtdb.firebaseio.com/cart.json',{
        method: 'PUT',
        body: JSON.stringify(cart),
      })
    },[cart]);

    return <div></div>

};

export default StoreInDatabase;