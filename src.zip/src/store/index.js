import { createStore } from "redux";
import { createSlice, configureStore } from "@reduxjs/toolkit";
const initialCounterState = { counter: 0, showCounter: true };

const countSlice = createSlice({
  name: "counter",
  initialState: initialCounterState,
  reducers: {
    increment(state) {
      state.counter++;
    },
    decrement(state) {
      state.counter--;
    },
    increase(state, action) {
      state.counter = state.counter + action.payload;
    },
    toogle(state) {
      state.showCounter = !state.showCounter;
    },
  },
});
const initialAuthState = { isLoggedIn: false };

const AuthSlice = createSlice({
  name: "Authentication",
  initialState: initialAuthState,
  reducers: {
    logIn(state) {
        state.isLoggedIn=true;
    },
    logOut(state) {
        state.isLoggedIn=false;
    },
  },
});

const store = configureStore({
  reducer: {
    counter: countSlice.reducer,
    auth: AuthSlice.reducer,
  },
});

export const counterAction = countSlice.actions;
export const authaction = AuthSlice.actions;

export default store;
