import { createSlice } from "@reduxjs/toolkit";
import AvailableMeals from "../components/Meals/AvailableMeals";

const CartSlice = createSlice({
  name: "cartItem",
  initialState: {
    items: [],
    totalAmount: 0,
  },
  reducers: {
    addToCart(state, action) {
      const newItem = action.payload;

      const existingItem = state.items.find((item) => item.id === newItem.id);
      if (!existingItem) {
        state.items.push({
          id: newItem.id,
          price: newItem.price,
          amount: newItem.amount,
          name: newItem.name,
        });
        const updatedTotalAmount = state.totalAmount + action.payload.price * action.payload.amount;
        state.totalAmount = updatedTotalAmount;
      } else {
        existingItem.amount++;
        const updatedTotalAmount = state.totalAmount + action.payload.price * action.payload.amount;
        state.totalAmount = updatedTotalAmount;
        //existingItem.price = existingItem.totalPrice + newItem.price;
      }
      
    },

    removeToCart(state, action) {
        const itemtodelete = action.payload;
        const existingItem = state.items.find(item=>item.id === itemtodelete.id);
        if(existingItem.amount ===1){
          state.items = state.items.filter(item =>item.id !==itemtodelete.id);
          state.totalAmount = state.totalAmount - itemtodelete.price;
        }else{
          existingItem.amount--;
          state.totalAmount = state.totalAmount - itemtodelete.price;
        }
    },
  },
});

export const CartSliceAction = CartSlice.actions;

export default CartSlice;
