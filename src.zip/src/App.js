import React from "react";
import Header from "./components/Layout/Header";
import AvailableItems from "./components/Items/availableItems";
import ItemContainer from "./components/UI/Button/ItemContainer";

import "./App.css";

function App() {
  return (
    <div>
      <Header />
      <AvailableItems />
    </div>
  );
}

export default App;
