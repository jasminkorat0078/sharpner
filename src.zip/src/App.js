import React, { useState} from "react";
import { Switch, Redirect, Route } from "react-router-dom";

import NewExpense from "./components/NewExpense/NewExpense";
import Expenses from "./components/Expenses/Expenses";
import SignUpForm from "./components/Authentication/SignUp";
import Header from "./components/UI/Header";
import LogIn from "./components/Authentication/LogIn";
import './App.css';
import WelcomePage from "./components/Welcome/WelcomePage";
import UpdateProfile from "./components/updateProfile/UpdateProfile";
import { useSelector } from "react-redux";



const App = () => {
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);
  const totalAmount = useSelector(state => state.expense.totalamount);
  let premium;
  if(totalAmount > 2000){
    premium = true;
  }
  else{
    premium = false;
  }

  //const expenses = [
  //   {
  //     id: 'e1',
  //     title: 'Toilet Paper',
  //     amount: 94.12,
  //     date: new Date(2020, 7, 14),
  //   },
  //   { id: 'e2', title: 'New TV', amount: 799.49, date: new Date(2021, 2, 12) },
  //   {
  //     id: 'e3',
  //     title: 'Car Insurance',
  //     amount: 294.67,
  //     date: new Date(2021, 2, 28),
  //   },
  //   {
  //     id: 'e4',
  //     title: 'New Desk (Wooden)',
  //     amount: 450,
  //     date: new Date(2021, 5, 12),
  //   },
  // ];

  // const [expenses, setExpenses] = useState(DUMMY_EXPENSES);

  // const addExpenseHandler = (expense) => {
  //   setExpenses((prevExpenses) => {
  //     return [expense, ...prevExpenses];
  //   });

  //   console.log("In App.js");
  //   console.log(expense);
  // };
  // const arr = expenses.map((data) => data["amount"]);
  // let total = 0;
  // arr.forEach((x) => {
  //   total += parseInt(x);
  // });
  // console.log("total amount")
  // console.log(total);

  // return React.createElement(
  //   'div',
  //   {},
  //   React.createElement('h2', {}, "Let's get started!"),
  //   React.createElement(Expenses, { items: expenses })
  // );

  return (
    <div>
      <Header />
      <Switch>
        <Route path="/" exact>
          <Redirect to="/login" />
        </Route>
        {!isLoggedIn && (
          <Route path="/login" exact>
            <LogIn />
          </Route>
        )}

        {!isLoggedIn && (
          <Route path="/signup" exact>
            <SignUpForm />
          </Route>
        )}

        {isLoggedIn && (
          <Route path="/addexpense" exact>
            <NewExpense  />
            <div className="premium">
            {premium && <div>Your Premium feature is activated. Now you can download your expense.</div>}
            {!premium && <div>Your Premium feature will be activated when expense amount will be greater than 10000 and you can download your expense in premium feature.</div>}

            </div>
           
            <Expenses  />
          </Route>
        )}
        {isLoggedIn && (
          <Route path="/welcome">
            <WelcomePage />
          </Route>
        )}

        {isLoggedIn && (
          <Route path="/updateprofile">
            <UpdateProfile />
          </Route>
        )}
       

        <Route path="/*" exact>
          <Redirect to="/login" />
        </Route>
        {isLoggedIn && <p>user logged in</p>}
      </Switch>

      {/* <NewExpense onAddExpense={addExpenseHandler} />
      <Expenses items={expenses} /> */}
    </div>
  );
};

export default App;
