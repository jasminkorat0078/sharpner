import './ItemContainer';
const ItemContainer = props =>{
    return <div className="container">{props.children}</div>
}

export default ItemContainer;