import { Fragment } from 'react';
import { useSelector, useDispatch } from 'react-redux';


import { Link } from 'react-router-dom';
import { authAction } from '../store/auth-slice';



import classes from './Header.module.css';

const Header = (props) => {
  const dispatch = useDispatch();
  const isLoggedIn =useSelector(state => state.auth.isLoggedIn);
  const totalAmount = useSelector(state => state.expense.totalamount);
  const expense = useSelector(state =>state.expense.expense);
  let premium;
  if(totalAmount > 2000){
    premium = true;
  }
  else{
    premium = false;
  }
  
 

  const logoutHandler=()=>{
    dispatch(authAction.logOut());
  }
  const makeCSV = expense =>{
    return expense.map(data => `${data.title},${data.amount},${data.date}`).join("\n");
  }
  const onDownloadHandler=() =>{
    const data = [
      [1,2,3],
      [4,5,6]
    ];
    
    const a2 = document.getElementById('a2');
    const blob =new Blob(['Title,Amount,Date,\n',makeCSV(expense)]);
    a2.href = URL.createObjectURL(blob);
  }
 
  return (
    <Fragment>
      <header className={classes.header}>
        <h1>Expense Tracker</h1>
        <div className={classes.btnflex}>
          <Link to="/welcome"><button className={classes.Btn}>Home</button></Link>
          <Link to='/addexpense'><button className={classes.Btn}>Add Expense</button></Link>
          {premium && <a id='a2' download='expense.csv'><button className={classes.Btn} onClick={onDownloadHandler} >Download Expense</button></a>}
          
          {isLoggedIn && <button className={classes.Btn} onClick={logoutHandler}>Logout</button> }
       
          {!isLoggedIn && <Link to="/login"><button className={classes.Btn}>LogIn</button></Link> }
          
        </div>
        
        
      </header>
      
    </Fragment>
  );
};

export default Header;