import { Fragment } from 'react';
import { useSelector, useDispatch } from 'react-redux';


import { Link } from 'react-router-dom';
import { authAction } from '../store/auth-slice';



import classes from './Header.module.css';

const Header = (props) => {
  const dispatch = useDispatch();
  const isLoggedIn =useSelector(state => state.auth.isLoggedIn)
 

  const logoutHandler=()=>{
    dispatch(authAction.logOut());
  }
  return (
    <Fragment>
      <header className={classes.header}>
        <h1>Expense Tracker</h1>
        <div className={classes.btnflex}>
          <Link to="/welcome"><button className={classes.Btn}>Home</button></Link>
          <Link to='/addexpense'><button className={classes.Btn}>Add Expense</button></Link>
          
          {isLoggedIn && <button className={classes.Btn} onClick={logoutHandler}>Logout</button> }
          {!isLoggedIn && <Link to="/login"><button className={classes.Btn}>LogIn</button></Link> }
          
        </div>
        
        
      </header>
      
    </Fragment>
  );
};

export default Header;