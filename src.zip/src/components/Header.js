import classes from './Header.module.css';
import { authaction } from '../store';
import { useSelector, useDispatch } from 'react-redux';

const Header = () => {
  const logstatus = useSelector(state=>state.auth.isLoggedIn);
  const dispatch = useDispatch();

  const logouthandler=(event)=>{
    dispatch(authaction.logOut());


  }
  return (
    <header className={classes.header}>
      <h1>Redux Auth</h1>
      {logstatus && <nav>
        <ul>
          <li>
            <a href='/'>My Products</a>
          </li>
          <li>
            <a href='/'>My Sales</a>
          </li>
          <li>
            <button onClick={logouthandler}>Logout</button>
          </li> 
          
        </ul>
      </nav>}
      
    </header>
  );
};

export default Header;
