import './WelcomePage.css';
import { Link } from 'react-router-dom';

const WelcomePage = () => {
  return (
    <section className="welcomepagesection">
        <div className='welcomepagecontainer'>
            <div className='notification-container'>
                <div className='notification'>
                <div> Your profile is not completed. <Link to='/updateprofile'>Click Here</Link> to update profile</div>

                </div>
                
            </div>
            
            <div className='wrapper'>
            <h1>Welcome to Expense tracker</h1>
            <p>This is developed by Jasmin Korat.</p>
            <p>This is designed using React. You can add your expense and track it anytime. Here, firebase authentication is used. Your password is 100% secure.</p>
            <p>Here, firebase database is used to store data.</p>
     
      

            </div>
    

        </div>

      
    </section>
  );
};

export default WelcomePage;
