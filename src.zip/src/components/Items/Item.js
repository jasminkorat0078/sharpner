import './item.css'
const Items = props =>{
    console.log(props.img);


    return(
        <li>
            <div className='list'>
                <h3>{props.name}</h3>
                <img src={props.img}></img>
                
                <div>{`Price: ${props.price}`}</div>
            </div>
        </li>
    );

}

export default Items;
