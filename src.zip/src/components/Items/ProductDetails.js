import { useParams } from "react-router-dom";

const ProductDetails = props =>{
    const param = useParams();
    return <section>

        <h1>product name</h1>
        <div>{param.productID}</div>
    </section>

};

export default ProductDetails;