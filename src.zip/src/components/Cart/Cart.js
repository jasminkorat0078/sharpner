

import Modal from '../UI/Modal';
import CartItem from './CartItem';
import classes from './Cart.module.css';
const cartElements = [
  { 
  title: 'Colors', 
  price: 100,
  imageUrl: 'https://prasadyash2411.github.io/ecom-website/img/Album%201.png', 
  quantity: 2,
  },
  
  {
  title: 'Black and white Colors',
  price: 50,
  imageUrl: 'https://prasadyash2411.github.io/ecom-website/img/Album%202.png', 
  quantity: 3,
  }, 
  {
   title: 'Yellow and Black Colors',  
  price: 70, 
  imageUrl: 'https://prasadyash2411.github.io/ecom-website/img/Album%203.png',  
  quantity: 1, 
  }
  ]

const Cart = (props) => {
  
  const cartItemRemoveHandler = (key) => {};

  // const cartItemAddHandler = (item) => {};


  const cartItems = (
    <ul className={classes['cart-items']}>
      {cartElements.map((item) => (
        <CartItem
          key={Math.random()}
          name={item.title}
          price={item.price}
          img={item.imageUrl}
          onRemove={cartItemRemoveHandler.bind(null, item.id)}
          // onAdd={cartItemAddHandler.bind(null, item)}
          
        />
      ))}
    </ul>
  );

  return (
    <Modal onClose={props.onClose}>
      {cartItems}
      <div className={classes.total}>
        <span>Total Amount</span>
        <span>4</span>
      </div>
      <div className={classes.actions}>
        <button className={classes['button--alt']} onClick={props.onClose}>
          Close
        </button>
        <button className={classes.button}>Order</button>
      </div>
    </Modal>
  );
};

export default Cart;