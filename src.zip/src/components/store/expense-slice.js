import { createSlice } from "@reduxjs/toolkit";

const initialExpense = {
    expense : [
        { id: "e1", title: "Toilet Paper", amount: 94.12, date: "2020-07-14" },
        { id: "e2", title: "New TV", amount: 799.49, date:"2021-02-22"},
        {
          id: "e3",
          title: "Car Insurance",
          amount: 294.67,
          date: "2021-2-28",
        },
        {
          id: "e4",
          title: "New Desk (Wooden)",
          amount: 450,
          date: "2021-5-12",
        },
      ],
      totalamount: 1638.28,
   

}

const Expenseslice = createSlice({
  name: "expense",
  initialState: initialExpense,
  reducers: {
    addExpense(state, action) {
      const title = action.payload["title"];
      const amount = action.payload["amount"];
      const date = action.payload["date"];
      const id = action.payload["id"];
      const newExpense = {
        id: id,
        title: title,
        amount: amount,
        date: date,
      };
      const amountInt = parseInt(amount);
      
      state.totalamount = state.totalamount + amountInt;
      state.expense = [newExpense,...state.expense];
      


    //   state.expense = [newExpense, ...state.expense];
    //   console.log("new state");
    //   console.log(state);
    },
  },
});
export const Expenseaction = Expenseslice.actions;

export default Expenseslice;
