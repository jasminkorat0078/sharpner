import { createSlice } from "@reduxjs/toolkit";

const initialAuthStatus = {
    token:'',
    isLoggedIn:false,
}

const authSlice = createSlice({
    name:'authentication',
    initialState:initialAuthStatus,
    reducers:{
        logIn(state,action) {
            state.token = action.payload;
            state.isLoggedIn = true;
        },
        logOut(state) {
            state.isLoggedIn = false;
        }
    }

})
export const authAction = authSlice.actions;

export default authSlice;