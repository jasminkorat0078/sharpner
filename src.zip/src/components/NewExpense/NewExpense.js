import { useState } from "react";
import "./NewExpense.css";
import ExpenseForm from "./ExpenseForm";
import { useDispatch } from "react-redux";
import {Expenseaction} from '../store/expense-slice';

 
const NewExpense = (props) => {
  const [isEditing, setIsEditing] = useState(false);
  const dispatch = useDispatch();
  
  const saveExpenseDataHandler = (enteredExpenseData) => {
    const expenseData = {
      ...enteredExpenseData,
      id: Math.random().toString(),
    };
    //console.log(expenseData);
    //props.onAddExpense(expenseData);
    dispatch(Expenseaction.addExpense(expenseData));
    setIsEditing(false);
  };

  const startEditingHandler = () => {
    setIsEditing(true);
  };
  const stopEditingHandler = () => {
    setIsEditing(false);
  };


  return (
    <div className="new-expense">
      {!isEditing && (
        <button onClick={startEditingHandler}>Add New Expense</button>
        
      )}
      
      {isEditing && (
        <ExpenseForm
          onSaveExpenseData={saveExpenseDataHandler}
          onStop={stopEditingHandler}
        ></ExpenseForm>
      )}
    </div>
  );
};

export default NewExpense;
