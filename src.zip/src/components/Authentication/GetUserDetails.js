import AuthContext from "../store/auth-context";
import { useContext, useEffect } from "react";

const GetUserDetails = (props) => {
  const authctx = useContext(AuthContext);
  const url = "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=AIzaSyBawf_72sdwcoLf6_ToLskojR4Pxp0WC0I"
  useEffect(()=>{
      console.log("useeffect is called");
  });


 
  
};

export default GetUserDetails;
